fake archive contents
